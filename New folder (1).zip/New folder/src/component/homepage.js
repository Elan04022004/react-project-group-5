import React, { useEffect, useState } from 'react'
import MoviesList from './movieList'
import axios from 'axios';

function Homepage() {
    const [movies, setMovies] = useState(
        [
            {
                "Title": "leo",
                "Year": "2023",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/thumb/7/75/Leo_%282023_Indian_film%29.jpg/220px-Leo_%282023_Indian_film%29.jpg",
                "Trailer": "https://youtu.be/Po3jStA673E?si=fN8u99MkiVylvPHw"
            },
            {
                "Title": "Gilli",
                "Year": "2004",
                "Type": "Movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/thumb/1/13/Ghilli_poster.jpg/220px-Ghilli_poster.jpg",
                "Trailer": "https://youtu.be/EtJXEmW_XNM?si=N2y-ky4j6-fJ9Oaj"
            },
            {
                "Title": "Thalaiva",
                "Year": "2013",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/thumb/b/b1/Thalaivaa_poster.jpg/220px-Thalaivaa_poster.jpg",
                "Trailer": "https://youtu.be/4hYS1PoM4XM?si=pD1lFW34FC-Tvwe9"
            },
            {
                "Title": "Thirupachi",
                "Year": "2005",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/thumb/0/0a/Thirupaachi.jpg/220px-Thirupaachi.jpg",
                "Trailer": "https://youtu.be/ihu9jSxf_2Q?si=E2rVOKKfNW3XnS5u"
            },
            {
                "Title": "Mersal",
                "Year": "2017",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/3/3c/Mersal_film_poster.jpg",
                "Trailer": "https://youtu.be/gQDo5QuZTaw?si=_tTZIPSOWCtyqRLN"
            },
            {
                "Title": "The Greatest of All Time",
                "Year": "2024",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/1/1e/The_Greatest_of_All_Time.jpg",
                 "Trailer": "https://youtu.be/jxCRlebiebw?si=JqOSJyHX76f8segZ"
            },
            {
                "Title": "Kathi",
                "Year": "2014",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/thumb/9/90/Kaththi_poster.jpg/220px-Kaththi_poster.jpg",
                 "Trailer": "https://youtu.be/bMf0IyzyKt4?si=cAGx-UOnGcejoE_Q"
            },
            {
                "Title": "Theri",
                "Year": "2016",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/thumb/d/db/Theri_poster.jpg/220px-Theri_poster.jpg",
                "Trailer": "https://youtu.be/ZK4uGLpkAKk?si=UkB2enicZAJMw4F_"
            },
            {
                "Title": "Sura",
                "Year": "2010",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/thumb/9/97/Sura_Vijay.jpg/220px-Sura_Vijay.jpg",
                "Trailer": "https://youtu.be/zzTm07D8e-M?si=3JclCNQuucx0zA1I"
            },
            {
                "Title": "Thuppakki",
                "Year": "2012",
                "Type": "movie",
                "Poster": "https://upload.wikimedia.org/wikipedia/en/b/be/Thuppakki_poster.jpg",
                "Trailer": "https://youtu.be/aW_j4pNvG98?si=rLoZRLpqhxi1gZbe"
            }
        ]
    )

    // async function getMovies() {
    //     try {
    //         let response = await axios.get('');
    //         setMovies(response.data)
    //     } catch (error) {
    //         console.error(error);
    //     }
    // }

    // useEffect(() => {
        // getMovies()
    // }, [])

    return (
        <div style={{ display: 'flex', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', backgroundColor: 'red' }}>
            <MoviesList data={movies} />
        </div>
    )
}

export default Homepage
